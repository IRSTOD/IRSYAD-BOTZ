module.exports.mess = {
	        wait: '⏰ Perintah Di Laksanakan....',
			success: '✔️ Selesai Kak',
			wrongFormat: 'Format salah, coba liat lagi di menu',
			error: {
				api: 'Emror Bg',
				stick: 'ITU BUKAN STIKER TOLOL',
				Iv: 'JANGAN NGASIH LINK GAJE TOD'
			},
			only: {
				group: '😇 Only Grup Bruh...',
				admin: '😇 Only Admin Bruh....',
				premium: '😇 Only Premium Bruh....',
				owner: '😇 Only Owner Bruh...',
				Badmin: 'BOT HARUS JADI ADMIN BRO',
			}
		}